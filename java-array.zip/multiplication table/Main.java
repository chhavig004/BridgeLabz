import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("number: ");
        int num = sc.nextInt();
        for (int i=1;i<=10;i++){
            System.out.println(num * i);
        }
    }
}

